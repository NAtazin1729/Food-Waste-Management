package com.emranbdx.foodwasteagent.Utils;

public class Config {
    private String dbUrl="https://foodwaste-70b7d-default-rtdb.asia-southeast1.firebasedatabase.app/";
    private String API_KEY="AAAAMltpJ8c:APA91bHo2FnvCjZvgUyZDpQPGBBIm1vqBFtooCYY-LKjeD0Nz5320Yayu3Ui3L-xgBB2b8VthM10VUZWqzQphFXc0GYIJn-Vd15M04tmDibE42yqNKaV9ueUOfCS_7ViXc632sI3x5gW";

    public Config() {
    }

    public String getDbUrl() {
        return dbUrl;
    }
    public String getAPI_KEY() {
        return API_KEY;
    }
}
